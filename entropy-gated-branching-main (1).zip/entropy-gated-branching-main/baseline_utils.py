"""Utility helpers shared by the standalone baseline implementations.

This module intentionally lives outside of the existing runtime code so the
baseline scripts can be imported without mutating the current experiment
infrastructure.  Every helper here is written in a side-effect free fashion and
keeps CPU compatibility in case a user only wants to unit test the logic.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
import time

from typing import Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple, Union

import torch
from transformers import PreTrainedModel, PreTrainedTokenizerBase


ChatPrompt = Union[str, Sequence[Mapping[str, str]]]


@dataclass
class GeneratedSample:
    """Container for information about a single generated continuation."""

    text: str
    token_count: int
    logprob: float


def apply_chat_template(tokenizer: PreTrainedTokenizerBase, prompt: ChatPrompt) -> str:
    """Converts a prompt into a plain string using the tokenizer's chat template.

    Parameters
    ----------
    tokenizer:
        Tokenizer providing the `apply_chat_template` API.
    prompt:
        Either a raw string or a sequence of ``{"role": ..., "content": ...}``
        dictionaries describing a chat conversation.
    """

    if isinstance(prompt, str):
        return prompt

    try:
        return tokenizer.apply_chat_template(
            prompt,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        # Older tokenizers do not expose ``enable_thinking``.
        return tokenizer.apply_chat_template(
            prompt,
            tokenize=False,
            add_generation_prompt=True,
        )


def _batched_prompts(tokenizer: PreTrainedTokenizerBase, prompts: Sequence[ChatPrompt]) -> List[str]:
    """Applies :func:`apply_chat_template` to a sequence of prompts."""

    return [apply_chat_template(tokenizer, prompt) for prompt in prompts]


def _logprob_from_scores(
    scores: Sequence[torch.Tensor],
    generated_ids: torch.Tensor,
    eos_token_id: Optional[int],
) -> float:
    total_logprob = 0.0

    for step_idx, token_id in enumerate(generated_ids):
        if step_idx >= len(scores):
            break

        step_scores = scores[step_idx]
        log_probs = torch.nn.functional.log_softmax(step_scores, dim=-1)
        total_logprob += log_probs[token_id].item()

        if eos_token_id is not None and token_id.item() == eos_token_id:
            break

    return total_logprob


def generate_samples(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompt: ChatPrompt,
    *,
    num_samples: int,
    max_new_tokens: int,
    generation_kwargs: Optional[MutableMapping[str, object]] = None,
    device: Optional[Union[str, torch.device]] = None,
) -> List[GeneratedSample]:
    """Generates ``num_samples`` continuations for ``prompt``.

    The helper returns a list of :class:`GeneratedSample` objects containing
    decoded text, number of tokens, and the summed token-level log probability
    computed from the model's output scores.
    """

    if generation_kwargs is None:
        generation_kwargs = {}
    else:
        generation_kwargs = dict(generation_kwargs)

    if "max_new_tokens" in generation_kwargs:
        # Avoid sending duplicate ``max_new_tokens`` values to ``model.generate``.
        kwarg_max_new_tokens = int(generation_kwargs.pop("max_new_tokens"))
        if kwarg_max_new_tokens != max_new_tokens:
            max_new_tokens = kwarg_max_new_tokens

    prompt_text = apply_chat_template(tokenizer, prompt)
    enc = tokenizer(
        prompt_text,
        return_tensors="pt",
        padding=True,
        truncation=True,
    )

    if device is None:
        device = model.device

    enc = {k: v.to(device) for k, v in enc.items()}

    output = model.generate(
        **enc,
        return_dict_in_generate=True,
        output_scores=True,
        num_return_sequences=num_samples,
        max_new_tokens=max_new_tokens,
        **generation_kwargs,
    )

    input_len = enc["input_ids"].shape[-1]
    eos_token_id = model.generation_config.eos_token_id

    generated_sequences = output.sequences[:, input_len:]
    scores = output.scores or []

    samples: List[GeneratedSample] = []
    for seq_idx in range(generated_sequences.size(0)):
        seq_ids = generated_sequences[seq_idx]
        logprob = _logprob_from_scores(
            [score[seq_idx] for score in scores],
            seq_ids,
            eos_token_id,
        )
        text = tokenizer.decode(seq_ids, skip_special_tokens=True)
        if tokenizer.pad_token_id is None:
            token_count = int(seq_ids.numel())
        else:
            token_count = int((seq_ids != tokenizer.pad_token_id).sum().item())
        samples.append(GeneratedSample(text=text, token_count=token_count, logprob=logprob))

    return samples


def normalize_answer(text: str) -> str:
    """Normalizes a free-form answer string for majority voting."""

    import re

    text = text.strip().lower()
    text = re.sub(r"\bthe\b", "", text)
    text = re.sub(r"[^a-z0-9\.\-]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_final_answer(text: str) -> Optional[str]:
    """Extracts a short final answer from a reasoning trace."""

    import re

    if not text:
        return None

    def _clean(candidate: str) -> str:
        candidate = candidate.strip()
        if not candidate:
            return ""
        candidate = re.sub(r"\\boxed\{([^}]*)\}", r"\1", candidate)
        candidate = candidate.strip()
        candidate = re.sub(r"^[=:>\-\s$]+", "", candidate)
        candidate = candidate.strip(" \"'`“”‘’$")
        candidate = candidate.replace(",", "")
        candidate = candidate.rstrip(".!?,;:").strip()
        if candidate.startswith("(") and candidate.endswith(")") and len(candidate) > 2:
            inner = candidate[1:-1].strip()
            if inner:
                candidate = inner
        return candidate

    boxed_matches = re.findall(r"\\boxed\{([^}]*)\}", text)
    for candidate in reversed(boxed_matches):
        cleaned = _clean(candidate)
        if cleaned:
            return cleaned

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    answer_patterns = [
        r"(?:^|\b)(?:the\s+)?answer\s+(?:is|=|:)\s*(?P<answer>.+)",
        r"(?:^|\b)(?:the\s+)?final\s+answer\s*(?:is|=|:)\s*(?P<answer>.+)",
        r"(?:^|\b)so\s+the\s+answer\s*(?:is|=|:)\s*(?P<answer>.+)",
        r"(?:^|\b)thus\s+the\s+answer\s*(?:is|=|:)\s*(?P<answer>.+)",
        r"(?:^|\b)therefore\s+the\s+answer\s*(?:is|=|:)\s*(?P<answer>.+)",
        r"(?:^|\b)answer\s*[:=]\s*(?P<answer>.+)",
        r"(?:^|\b)ans\s*[:=]\s*(?P<answer>.+)",
    ]

    def _truncate_explanation(candidate: str) -> str:
        lowered = candidate.lower()
        for marker in [" because", " since", " therefore", " thus", " so"]:
            idx = lowered.find(marker)
            if idx > 0:
                candidate = candidate[:idx]
                break
        sentence_split = re.split(r"\.\s", candidate, maxsplit=1)
        candidate = sentence_split[0]
        return candidate

    for line in reversed(lines):
        for pattern in answer_patterns:
            match = re.search(pattern, line, re.IGNORECASE)
            if match:
                candidate = match.group("answer")
                candidate = _truncate_explanation(candidate)
                candidate = _clean(candidate)
                if candidate:
                    return candidate

    mc_patterns = [
        r"^\(?\s*([A-E])\s*\)?[\).]?$",
        r"(?:^|\b)option\s*\(?([A-E])\)?(?:$|[\).])",
        r"(?:^|\b)choice\s*\(?([A-E])\)?(?:$|[\).])",
    ]

    for line in reversed(lines):
        for pattern in mc_patterns:
            match = re.search(pattern, line, re.IGNORECASE)
            if match:
                candidate = match.group(1).upper()
                if candidate:
                    return candidate

    tail_matches = re.findall(r"\(([A-E])\)", text, re.IGNORECASE)
    if tail_matches:
        candidate = tail_matches[-1].upper()
        if candidate:
            return candidate

    hash_matches = re.findall(r"####\s*([^\n]+)", text)
    for candidate in reversed(hash_matches):
        cleaned = _clean(candidate)
        if cleaned:
            return cleaned

    bracket_matches = re.findall(r"\[([^\[\]]{1,64})\]", text)
    for candidate in reversed(bracket_matches):
        cleaned = _clean(candidate)
        if cleaned:
            return cleaned

    number_matches = re.findall(r"[-+]?\$?\d[\d,]*\.?\d*", text)
    for candidate in reversed(number_matches):
        cleaned = _clean(candidate)
        if cleaned:
            return cleaned

    return None


def majority_vote(
    candidates: Sequence[str],
    *,
    normalizer: Callable[[str], str] = normalize_answer,
    answer_extractor: Optional[Callable[[str], Optional[str]]] = extract_final_answer,
) -> Tuple[str, Dict[str, int]]:
    """Returns the majority-vote answer and vote counts."""

    from collections import Counter

    normalized: List[str] = []
    representatives: Dict[str, str] = {}

    for idx, candidate in enumerate(candidates):
        extracted: Optional[str] = None
        if answer_extractor is not None:
            try:
                extracted = answer_extractor(candidate)
            except Exception:
                extracted = None

        if extracted:
            key = normalizer(extracted)
        else:
            key = ""

        if not key:
            key = normalizer(candidate)
            value = candidate
        else:
            value = extracted

        if not key:
            continue

        normalized.append(key)
        if key not in representatives:
            representatives[key] = value

    counts = Counter(normalized)
    if not counts:
        return "", {}

    winner_key, _ = counts.most_common(1)[0]
    winner_value = representatives[winner_key]

    vote_counts = {representatives[key]: counts[key] for key in counts}
    return winner_value, vote_counts


def final_answer_majority_vote(
    candidates: Sequence[str],
    *,
    normalizer: Callable[[str], str] = normalize_answer,
    answer_extractor: Callable[[str], Optional[str]] = extract_final_answer,
) -> Tuple[str, Dict[str, int]]:
    """Aggregation helper that majority-votes over extracted final answers."""

    return majority_vote(
        candidates,
        normalizer=normalizer,
        answer_extractor=answer_extractor,
    )


def select_best_by_score(
    candidates: Sequence[GeneratedSample],
    *,
    score_fn: Callable[[GeneratedSample], float],
) -> Tuple[GeneratedSample, List[float]]:
    """Selects the candidate with the highest ``score_fn`` value."""

    if not candidates:
        raise ValueError("No candidates provided")

    scores = [score_fn(candidate) for candidate in candidates]
    best_idx = int(torch.tensor(scores).argmax().item())
    return candidates[best_idx], scores


@contextmanager
def generation_timer():
    """Context manager that records wall-clock timing metadata for a decode."""

    started_at = datetime.utcnow().isoformat() + "Z"
    start = time.perf_counter()
    telemetry = {"started_at": started_at}
    try:
        yield telemetry
    finally:
        telemetry["ended_at"] = datetime.utcnow().isoformat() + "Z"
        telemetry["total_wall_time_s"] = time.perf_counter() - start


def chunk_list(sequence: Sequence[object], chunk_size: int) -> Iterable[Sequence[object]]:
    """Simple helper to iterate over ``sequence`` in chunks of ``chunk_size``."""

    for i in range(0, len(sequence), chunk_size):
        yield sequence[i : i + chunk_size]
