"""Self-consistency baseline implementation.

The module exposes :class:`SelfConsistencyBaseline`, a lightweight utility that
can be imported from notebooks or scripts without modifying the existing
benchmark harness.  The class expects a pre-loaded model and tokenizer and
produces majority-vote answers together with vote diagnostics.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Callable, Dict, List, Optional, Sequence, Tuple, Union

import torch

from transformers import GenerationConfig, PreTrainedModel, PreTrainedTokenizerBase
from baseline_utils import (
    GeneratedSample,
    final_answer_majority_vote,
    generate_samples,
    generation_timer,
    apply_chat_template,
    extract_final_answer,
)



@dataclass
class SelfConsistencyConfig:
    """Configuration controlling the self-consistency decoding behaviour."""

    samples: int = 10
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 0
    max_new_tokens: int = 512
    aggregation_fn: Callable[[Sequence[str]], Tuple[str, Dict[str, int]]] = final_answer_majority_vote
    use_answer_extractor: bool = False
    answer_extractor_max_new_tokens: int = 64
    answer_extractor_temperature: float = 0.0
    answer_extractor_system_prompt: str = (
        "You are a careful grader. Given the user's question and an assistant's reasoning, "
        "extract the final concise answer. Respond using the format [answer] with no additional text."
    )
    answer_extractor_user_template: str = (
        "Question:\n{question}\n\nAssistant reasoning:\n{reasoning}\n\n"
        "Return only the final answer enclosed in square brackets."
    )


class SelfConsistencyBaseline:
    """Draws multiple stochastic completions and aggregates via majority vote."""

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizerBase,
        config: Optional[SelfConsistencyConfig] = None,
        *,
        device: Optional[str] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or SelfConsistencyConfig()
        self.device = device or str(model.device)

    def _generation_kwargs(self) -> Dict[str, object]:
        cfg = self.config
        kwargs: Dict[str, object] = {
            "do_sample": True,
            "temperature": cfg.temperature,
            "top_p": cfg.top_p,
        }
        if cfg.top_k:
            kwargs["top_k"] = cfg.top_k
        return kwargs

    def generate(self, prompt) -> Dict[str, object]:
        """Generates self-consistent answer for ``prompt``.

        Returns a dictionary containing the chosen response, raw samples and the
        vote histogram so callers can inspect the decode diversity.
        """

        with generation_timer() as timing:
            samples: List[GeneratedSample] = generate_samples(
                self.model,
                self.tokenizer,
                prompt,
                num_samples=self.config.samples,
                max_new_tokens=self.config.max_new_tokens,
                generation_kwargs=self._generation_kwargs(),
                device=self.device,
            )

            responses = [sample.text for sample in samples]

            if self.config.use_answer_extractor:
                question_text = self._question_from_prompt(prompt)
                responses = [
                    self._extract_with_prompt(question_text, response) if question_text else response
                    for response in responses
                ]

            winner, vote_counts = self.config.aggregation_fn(responses)


        return {
            "response": winner,
            "samples": [
                {
                    "text": sample.text,
                    "logprob": sample.logprob,
                    "token_count": sample.token_count,
                }
                for sample in samples
            ],
            "vote_counts": vote_counts,
            "timing": timing,
        }

    def _question_from_prompt(self, prompt: Union[str, Sequence[Dict[str, str]]]) -> str:
        if isinstance(prompt, str):
            return prompt

        for message in reversed(prompt):
            if isinstance(message, dict) and message.get("role") == "user":
                content = message.get("content")
                if isinstance(content, str):
                    return content
        return ""

    def _extract_with_prompt(self, question: str, reasoning: str) -> str:
        if not question:
            return reasoning

        messages = [
            {"role": "system", "content": self.config.answer_extractor_system_prompt},
            {
                "role": "user",
                "content": self.config.answer_extractor_user_template.format(
                    question=question,
                    reasoning=reasoning,
                ),
            },
        ]

        prompt_text = apply_chat_template(self.tokenizer, messages)

        enc = self.tokenizer(
            prompt_text,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )
        enc = {k: v.to(self.device) for k, v in enc.items()}

        generation_config = GenerationConfig.from_model_config(self.model.config)
        generation_config.max_new_tokens = self.config.answer_extractor_max_new_tokens
        generation_config.do_sample = False
        generation_config.num_return_sequences = 1

        if self.config.answer_extractor_temperature and self.config.answer_extractor_temperature > 0:
            generation_config.do_sample = True
            generation_config.temperature = self.config.answer_extractor_temperature
        else:
            generation_config.temperature = 1.0
            generation_config.top_p = 1.0

        if self.model.config.pad_token_id is not None:
            generation_config.pad_token_id = self.model.config.pad_token_id

        with torch.no_grad():
            output = self.model.generate(**enc, generation_config=generation_config)

        input_len = enc["input_ids"].shape[-1]
        decoded = self.tokenizer.decode(
            output[0][input_len:],
            skip_special_tokens=True,
        ).strip()

        extracted = extract_final_answer(decoded)
        if extracted and not self._is_placeholder_response(extracted):
            return extracted

        match = re.search(r"\[([^\[\]]+)\]", decoded)
        if match:
            bracket_content = match.group(1).strip()
            bracket_extracted = extract_final_answer(bracket_content)
            if bracket_extracted and not self._is_placeholder_response(bracket_extracted):
                return bracket_extracted
            if bracket_content and not self._is_placeholder_response(bracket_content):
                return bracket_content

        cleaned = decoded.strip()
        if cleaned and not self._is_placeholder_response(cleaned):
            fallback_extracted = extract_final_answer(cleaned)
            if fallback_extracted and not self._is_placeholder_response(fallback_extracted):
                return fallback_extracted
            return cleaned

        return reasoning

    @staticmethod
    def _is_placeholder_response(text: str) -> bool:
        if not text:
            return True

        normalized = re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()
        if not normalized:
            return True

        placeholder_exact = {
            "answer",
            "the answer",
            "final answer",
            "final",
            "final answers",
            "answer final",
        }
        if normalized in placeholder_exact:
            return True

        if normalized in {"na", "n a", "n slash a", "n-slash-a"}:
            return True

        words = normalized.split()
        if words and not any(char.isdigit() for char in normalized):
            placeholder_vocab = {"the", "final", "answer", "answers", "is", "are"}
            if all(word in placeholder_vocab for word in words):
                return True

        return False
