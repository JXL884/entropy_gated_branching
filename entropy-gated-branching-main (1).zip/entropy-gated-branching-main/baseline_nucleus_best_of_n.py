"""Nucleus best-of-N baseline implementation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Optional

from transformers import PreTrainedModel, PreTrainedTokenizerBase
from baseline_utils import (
    GeneratedSample,
    generate_samples,
    generation_timer,
    select_best_by_score,
)



ScoreFn = Callable[[GeneratedSample], float]


@dataclass
class NucleusBestOfNConfig:
    samples: int = 10
    top_p: float = 0.9
    temperature: float = 0.7
    top_k: int = 0
    max_new_tokens: int = 512
    score_fn: Optional[ScoreFn] = None


def _default_score(sample: GeneratedSample) -> float:
    return sample.logprob


class NucleusBestOfN:
    """Samples ``N`` nucleus continuations and selects the highest scoring one."""

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizerBase,
        config: Optional[NucleusBestOfNConfig] = None,
        *,
        device: Optional[str] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or NucleusBestOfNConfig()
        self.device = device or str(model.device)
        self.score_fn: ScoreFn = self.config.score_fn or _default_score

    def _generation_kwargs(self) -> Dict[str, object]:
        cfg = self.config
        kwargs: Dict[str, object] = {
            "do_sample": True,
            "top_p": cfg.top_p,
            "temperature": cfg.temperature,
        }
        if cfg.top_k:
            kwargs["top_k"] = cfg.top_k
        return kwargs

    def generate(self, prompt) -> Dict[str, object]:
        cfg = self.config
        with generation_timer() as timing:
            samples = generate_samples(
                self.model,
                self.tokenizer,
                prompt,
                num_samples=cfg.samples,
                max_new_tokens=cfg.max_new_tokens,
                generation_kwargs=self._generation_kwargs(),
                device=self.device,
            )

            winner, scores = select_best_by_score(samples, score_fn=self.score_fn)


        return {
            "response": winner.text,
            "score": self.score_fn(winner),
            "logprob": winner.logprob,
            "token_count": winner.token_count,
            "samples": [
                {
                    "text": sample.text,
                    "logprob": sample.logprob,
                    "token_count": sample.token_count,
                }
                for sample in samples
            ],
            "scores": scores,
            "timing": timing,
        }

