"""Self-evaluation-guided stochastic beam search baseline."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import torch
from transformers import PreTrainedModel, PreTrainedTokenizerBase
from baseline_utils import (
    apply_chat_template,
    GeneratedSample,
    generate_samples,
    generation_timer,
    ChatPrompt,
)



ScoreFn = Callable[[GeneratedSample], float]


@dataclass
class SEGSConfig:
    """Configuration for the SEGS-inspired baseline."""

    beam_width: int = 4
    expansions_per_step: int = 2
    iterations: int = 2
    temperature: float = 0.7
    top_p: float = 0.9
    max_new_tokens: int = 512
    length_penalty: float = 0.0
    confidence_weight: float = 0.5
    score_fn: Optional[ScoreFn] = None
    evaluation_prompt: str = (
        "Please answer yes or no: Is the reasoning above correct?"
    )
    evaluation_positive: str = "Yes."
    evaluation_negative: str = "No."


def _default_score(sample: GeneratedSample) -> float:
    length = max(sample.token_count, 1)
    return sample.logprob / float(length)


@dataclass
class _BeamCandidate:
    sample: GeneratedSample
    evaluation_probability: float
    evaluation_logprob: float
    model_score: float
    combined_log_score: float

    def key(self) -> Tuple[float, float]:
        return (self.combined_log_score, self.evaluation_probability)


class SelfEvaluationGuidedStochasticBeamSearch:
    """Implementation of Self-Evaluation-Guided Stochastic Beam Search.

    The rewritten baseline mirrors the procedure described by Xie et al.
    (2023): we keep a beam of partial reasoning traces, expand each trace with
    stochastic decoding, and score the resulting continuations by asking the
    model to self-evaluate whether the reasoning is correct.  The beam is
    updated after every round so that high-quality continuations discovered in
    earlier iterations persist, and the final response is the candidate with
    the highest self-evaluation probability (breaking ties via the underlying
    model score).
    """

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizerBase,
        config: Optional[SEGSConfig] = None,
        *,
        device: Optional[str] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or SEGSConfig()
        self.device = torch.device(device or model.device)
        self.score_fn: ScoreFn = self.config.score_fn or _default_score
        self._confidence_weight = max(0.0, min(1.0, self.config.confidence_weight))

    def _generation_kwargs(self) -> Dict[str, object]:
        cfg = self.config
        return {
            "do_sample": True,
            "temperature": cfg.temperature,
            "top_p": cfg.top_p,
        }

    def _initial_candidate(self) -> _BeamCandidate:
        empty_sample = GeneratedSample(text="", token_count=0, logprob=0.0)
        return _BeamCandidate(
            sample=empty_sample,
            evaluation_probability=0.0,
            evaluation_logprob=float("-inf"),
            model_score=float("-inf"),
            combined_log_score=float("-inf"),
        )

    def _normalize_prompt(self, prompt: ChatPrompt) -> List[Dict[str, str]]:
        if isinstance(prompt, str):
            return [{"role": "user", "content": prompt}]
        return [
            {"role": message["role"], "content": message["content"]}
            for message in prompt
        ]

    def _merge_samples(
        self, parent: GeneratedSample, extension: GeneratedSample
    ) -> GeneratedSample:
        combined_text = parent.text + extension.text
        combined_tokens = parent.token_count + extension.token_count
        combined_logprob = parent.logprob + extension.logprob
        return GeneratedSample(
            text=combined_text,
            token_count=combined_tokens,
            logprob=combined_logprob,
        )

    def _logprob_of_response(self, prompt_text: str, response_text: str) -> float:
        tokenizer = self.tokenizer
        prompt_enc = tokenizer(
            prompt_text,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )
        response_ids = tokenizer(
            response_text,
            add_special_tokens=False,
            return_tensors="pt",
        )["input_ids"]

        input_ids = torch.cat([prompt_enc["input_ids"], response_ids], dim=-1)
        base_attention = prompt_enc.get(
            "attention_mask", torch.ones_like(prompt_enc["input_ids"])
        )
        attention_mask = torch.cat(
            [base_attention, torch.ones_like(response_ids)],
            dim=-1,
        )

        model_inputs = {
            "input_ids": input_ids.to(self.device),
            "attention_mask": attention_mask.to(self.device),
        }
        if "token_type_ids" in prompt_enc:
            token_type_ids = prompt_enc["token_type_ids"]
            last_token_type = token_type_ids[:, -1:]
            token_type_extension = last_token_type.expand_as(response_ids)
            model_inputs["token_type_ids"] = torch.cat(
                [token_type_ids, token_type_extension],
                dim=-1,
            ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**model_inputs)

        logits = outputs.logits[:, :-1, :]
        log_probs = torch.nn.functional.log_softmax(logits, dim=-1)

        prompt_len = int(prompt_enc["input_ids"].shape[-1])
        total_logprob = 0.0
        for idx in range(response_ids.shape[-1]):
            position = prompt_len + idx
            prev_position = position - 1
            token_id = input_ids[0, position]
            total_logprob += log_probs[0, prev_position, token_id].item()

        return float(total_logprob)

    def _self_evaluate(
        self,
        base_messages: Sequence[Dict[str, str]],
        reasoning_text: str,
    ) -> Tuple[float, float]:
        cfg = self.config
        messages: List[Dict[str, str]] = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in base_messages
        ]
        messages.append({"role": "assistant", "content": reasoning_text})
        messages.append({"role": "user", "content": cfg.evaluation_prompt})

        eval_prompt = apply_chat_template(self.tokenizer, messages)
        yes_logprob = self._logprob_of_response(eval_prompt, cfg.evaluation_positive)
        no_logprob = self._logprob_of_response(eval_prompt, cfg.evaluation_negative)

        max_logprob = max(yes_logprob, no_logprob)
        yes_weight = math.exp(yes_logprob - max_logprob)
        no_weight = math.exp(no_logprob - max_logprob)
        denom = yes_weight + no_weight

        if denom == 0.0:
            probability = 0.5
        else:
            probability = yes_weight / denom

        probability = max(0.0, min(1.0, probability))
        logprob = math.log(max(probability, 1e-12))
        return probability, logprob

    def _combined_log_score(
        self,
        evaluation_logprob: float,
        model_score: float,
        sample: GeneratedSample,
    ) -> float:
        weight = self._confidence_weight
        combined = weight * evaluation_logprob + (1.0 - weight) * model_score
        if self.config.length_penalty:
            combined -= self.config.length_penalty * float(sample.token_count)
        return combined

    def generate(self, prompt) -> Dict[str, object]:
        cfg = self.config
        beam: List[_BeamCandidate] = []
        history: List[Dict[str, object]] = []

        base_messages = self._normalize_prompt(prompt)
        base_prompt_text = apply_chat_template(self.tokenizer, base_messages)
        num_samples = max(cfg.expansions_per_step, 1)

        with generation_timer() as timing:
            for iteration in range(cfg.iterations):
                parents = beam if beam else [self._initial_candidate()]
                generated_candidates: List[_BeamCandidate] = []

                for parent in parents:
                    prompt_text = f"{base_prompt_text}{parent.sample.text}"
                    samples = generate_samples(
                        self.model,
                        self.tokenizer,
                        prompt_text,
                        num_samples=num_samples,
                        max_new_tokens=cfg.max_new_tokens,
                        generation_kwargs=self._generation_kwargs(),
                        device=self.device,
                    )

                    for sample in samples:
                        combined = self._merge_samples(parent.sample, sample)
                        eval_prob, eval_logprob = self._self_evaluate(
                            base_messages, combined.text
                        )
                        model_score = self.score_fn(combined)
                        combined_log_score = self._combined_log_score(
                            eval_logprob,
                            model_score,
                            combined,
                        )
                        generated_candidates.append(
                            _BeamCandidate(
                                sample=combined,
                                evaluation_probability=eval_prob,
                                evaluation_logprob=eval_logprob,
                                model_score=model_score,
                                combined_log_score=combined_log_score,
                            )
                        )

                if not generated_candidates:
                    break

                pool = [cand for cand in beam if cand.sample.text]
                pool.extend(generated_candidates)
                pool.sort(key=lambda cand: cand.key(), reverse=True)
                beam = pool[: cfg.beam_width]

                history.append(
                    {
                        "iteration": iteration,
                        "candidates": [
                            {
                                "text": cand.sample.text,
                                "evaluation_probability": cand.evaluation_probability,
                                "evaluation_logprob": cand.evaluation_logprob,
                                "model_score": cand.model_score,
                                "combined_log_score": cand.combined_log_score,
                                "logprob": cand.sample.logprob,
                                "token_count": cand.sample.token_count,
                            }
                            for cand in beam
                        ],
                    }
                )

        if beam:
            winner = beam[0]
        else:
            winner = self._initial_candidate()

        return {
            "response": winner.sample.text,
            "score": winner.evaluation_probability,
            "logprob": winner.sample.logprob,
            "token_count": winner.sample.token_count,
            "evaluation_probability": winner.evaluation_probability,
            "evaluation_logprob": winner.evaluation_logprob,
            "model_score": winner.model_score,
            "combined_log_score": winner.combined_log_score,
            "beam_history": history,
            "final_scores": [
                {
                    "text": cand.sample.text,
                    "evaluation_probability": cand.evaluation_probability,
                    "evaluation_logprob": cand.evaluation_logprob,
                    "model_score": cand.model_score,
                    "combined_log_score": cand.combined_log_score,
                    "logprob": cand.sample.logprob,
                    "token_count": cand.sample.token_count,
                }
                for cand in beam
            ],
            "timing": timing,
        }
