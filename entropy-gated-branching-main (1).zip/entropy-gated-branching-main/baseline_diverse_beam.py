"""Diverse Beam Search baseline."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from transformers import PreTrainedModel, PreTrainedTokenizerBase
from baseline_utils import generate_samples, generation_timer, select_best_by_score



@dataclass
class DiverseBeamConfig:
    num_beams: int = 4
    num_beam_groups: int = 2
    diversity_penalty: float = 0.3
    temperature: float = 1.0
    top_p: float = 1.0
    max_new_tokens: int = 512


class DiverseBeamSearchBaseline:
    """Wraps Hugging Face's diverse beam search in a reusable helper."""

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizerBase,
        config: Optional[DiverseBeamConfig] = None,
        *,
        device: Optional[str] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or DiverseBeamConfig()
        self.device = device or str(model.device)

    def _generation_kwargs(self) -> Dict[str, object]:
        cfg = self.config
        return {
            "do_sample": False,
            "num_beams": cfg.num_beams,
            "num_beam_groups": cfg.num_beam_groups,
            "diversity_penalty": cfg.diversity_penalty,
            "temperature": cfg.temperature,
            "top_p": cfg.top_p,
        }

    def generate(self, prompt) -> Dict[str, object]:
        with generation_timer() as timing:
            samples = generate_samples(
                self.model,
                self.tokenizer,
                prompt,
                num_samples=self.config.num_beams,
                max_new_tokens=self.config.max_new_tokens,
                generation_kwargs=self._generation_kwargs(),
                device=self.device,
            )

            winner, scores = select_best_by_score(samples, score_fn=lambda s: s.logprob)


        return {
            "response": winner.text,
            "logprob": winner.logprob,
            "token_count": winner.token_count,
            "beam_candidates": [
                {
                    "text": sample.text,
                    "logprob": sample.logprob,
                    "token_count": sample.token_count,
                }
                for sample in samples
            ],
            "candidate_scores": scores,
            "timing": timing,

        }

