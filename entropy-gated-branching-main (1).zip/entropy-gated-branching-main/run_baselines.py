from __future__ import annotations

import argparse
import json
import os
from datetime import datetime
from typing import Any, Dict

import pandas as pd
import torch
from datasets import load_dataset, load_from_disk, DatasetDict
from rich import print as rprint
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.utils.quantization_config import BitsAndBytesConfig

from baseline_conditional_poisson import (
    ConditionalPoissonBeamSearch,
    ConditionalPoissonConfig,
)
from baseline_diverse_beam import DiverseBeamConfig, DiverseBeamSearchBaseline
from baseline_nucleus_best_of_n import NucleusBestOfN, NucleusBestOfNConfig
from baseline_segs import (
    SEGSConfig,
    SelfEvaluationGuidedStochasticBeamSearch,
)
from baseline_self_consistency import (
    SelfConsistencyBaseline,
    SelfConsistencyConfig,
)
from accelerate import Accelerator

BASELINE_CHOICES = {
    "self_consistency": "Self-Consistency",
    "segs": "Self-Evaluation-Guided Stochastic Beam Search",
    "diverse_beam": "Diverse Beam Search",
    "conditional_poisson": "Conditional-Poisson Beam Search",
    "nucleus_best_of_n": "Nucleus Best-of-N",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run baseline decoding strategies on benchmark datasets",
    )

    # Model parameters
    parser.add_argument(
        "--model",
        type=str,
        default="Qwen/Qwen3-1.7B",
        help="Generator model name (e.g., Qwen/Qwen3-1.7B, meta-llama/Llama-3.1-8B-Instruct)",
    )
    parser.add_argument(
        "--quantize",
        action="store_true",
        help="Load the generator using 4-bit quantization",
    )

    # Baseline selection
    parser.add_argument(
        "--baseline",
        type=str,
        default="self_consistency",
        choices=list(BASELINE_CHOICES.keys()),
        help="Baseline method to run",
    )
    parser.add_argument(
        "--max-new-tokens",
        type=int,
        default=1024,
        help="Maximum number of new tokens each baseline may generate",
    )

    # Dataset parameters
    parser.add_argument(
        "--exam",
        type=str,
        default="gsm",
        choices=["l1", "l2", "gsm", "math", "aime"],
        help="Dataset/exam to evaluate",
    )
    parser.add_argument("--limit", type=int, default=None, help="Limit number of questions to process")
    parser.add_argument("--start", type=int, default=1, help="Start from question number (1-indexed)")

    # Output parameters
    parser.add_argument(
        "-o",
        "--out",
        type=str,
        default=None,
        help="Output directory for all results (default: {baseline}_{model}_{exam}_{timestamp})",
    )
    parser.add_argument("-q", "--quiet", action="store_true", help="Reduce console output")

    # Self-consistency controls
    parser.add_argument("--sc-samples", type=int, default=16, help="Number of samples for self-consistency")
    parser.add_argument("--sc-temperature", type=float, default=0.7, help="Sampling temperature for self-consistency")
    parser.add_argument("--sc-top-p", type=float, default=0.9, help="Top-p value for self-consistency")
    parser.add_argument("--sc-top-k", type=int, default=0, help="Top-k value for self-consistency (0 disables)")
    parser.add_argument(
        "--sc-use-answer-extractor",
        action="store_true",
        help="After generating each sample, run an auxiliary extraction prompt that asks the model to restate the final answer inside square brackets.",
    )
    parser.add_argument(
        "--sc-extractor-max-new-tokens",
        type=int,
        default=32,
        help="Maximum new tokens for the auxiliary answer extractor prompt.",
    )
    parser.add_argument(
        "--sc-extractor-temperature",
        type=float,
        default=0.0,
        help="Sampling temperature for the auxiliary answer extractor prompt (0 for greedy).",
    )

    # SEGS controls
    parser.add_argument("--segs-beam-width", type=int, default=4, help="Beam width for SEGS baseline")
    parser.add_argument(
        "--segs-expansions",
        type=int,
        default=4,
        help="Expansions per step for SEGS baseline",
    )
    parser.add_argument("--segs-iterations", type=int, default=2, help="Iterations for SEGS baseline")
    parser.add_argument("--segs-temperature", type=float, default=0.7, help="Temperature for SEGS sampling")
    parser.add_argument("--segs-top-p", type=float, default=0.9, help="Top-p for SEGS sampling")

    # Diverse beam controls
    parser.add_argument("--dbs-num-beams", type=int, default=4, help="Number of beams for diverse beam search")
    parser.add_argument("--dbs-num-groups", type=int, default=2, help="Number of beam groups for diversity")
    parser.add_argument(
        "--dbs-diversity-penalty",
        type=float,
        default=0.3,
        help="Diversity penalty applied across groups",
    )
    parser.add_argument("--dbs-temperature", type=float, default=1.0, help="Temperature for diverse beam search")
    parser.add_argument("--dbs-top-p", type=float, default=1.0, help="Top-p for diverse beam search")

    # Conditional-Poisson controls
    parser.add_argument(
        "--cp-beam-width",
        type=int,
        default=4,
        help="Beam width (number of candidates retained) for conditional-Poisson baseline",
    )
    parser.add_argument(
        "--cp-candidate-multiplier",
        type=int,
        default=4,
        help="Multiplier controlling how many candidates are sampled before CP selection",
    )
    parser.add_argument("--cp-temperature", type=float, default=0.7, help="Sampling temperature for CP baseline")
    parser.add_argument("--cp-top-p", type=float, default=0.95, help="Top-p for CP baseline")

    # Nucleus best-of-N controls
    parser.add_argument("--nucleus-samples", type=int, default=10, help="Number of nucleus samples to draw")
    parser.add_argument("--nucleus-top-p", type=float, default=0.9, help="Top-p for nucleus sampling")
    parser.add_argument(
        "--nucleus-temperature",
        type=float,
        default=0.7,
        help="Sampling temperature for nucleus baseline",
    )
    parser.add_argument("--nucleus-top-k", type=int, default=0, help="Optional top-k for nucleus baseline (0 disables)")

    return parser.parse_args()


def load_exam_data(exam_type, limit=None, start=1):
    """Load exam data based on the specified type."""

    def _dataset_to_dataframe(dataset, preferred_split=None):
        if isinstance(dataset, DatasetDict):
            if preferred_split and preferred_split in dataset:
                dataset = dataset[preferred_split]
            else:
                for split_name in ("test", "validation", "train"):
                    if split_name in dataset:
                        dataset = dataset[split_name]
                        break
                else:
                    dataset = next(iter(dataset.values()))

        if hasattr(dataset, "to_pandas"):
            try:
                return dataset.to_pandas()
            except Exception:
                return pd.DataFrame(dataset)
        return pd.DataFrame(dataset)

    if exam_type == "l1":
        df = pd.read_json("data/l1_exams.json")
    elif exam_type == "l2":
        df = pd.read_json("data/l2_exams.json")
    elif exam_type == "l3":
        df = pd.read_json("data/l3_exams.json")
    elif exam_type == "gsm":
        dataset = load_from_disk("./dataset_cache/gsm8k")
        df = _dataset_to_dataframe(dataset)
    elif exam_type == "math":
        dataset = load_from_disk("./dataset_cache/math")
        df = _dataset_to_dataframe(dataset, preferred_split="test")
        df = df.rename(columns={"problem": "question"})
    elif exam_type == "aime":
        dataset = load_from_disk("./dataset_cache/aime")
        df = _dataset_to_dataframe(dataset, preferred_split="train")
        df = df.rename(columns={"problem": "question"})
    else:
        raise ValueError(f"Unknown exam type: {exam_type}")

    # Apply start and limit
    start_idx = start - 1  # Convert to 0-indexed
    if limit:
        end_idx = start_idx + limit
        return df.iloc[start_idx:end_idx]
    else:
        return df.iloc[start_idx:]


def format_prompt(exam_type: str, question_row: pd.Series) -> list[Dict[str, str]]:
    if exam_type in ("l1", "l2", "l3"):
        system_prompt = (
            "You are an expert financial analyst.\n"
            "You are given questions about various financial topics, from quantitative analysis to portfolio management to ethics of being a chartered financial analyst (CFA).\n"
            "Each question includes 3 potential answers, A B and C, one of which is correct (or in some cases, more correct than the others).\n"
            "Indicate the correct answer: A, B, or C."
        )
        question_text = question_row.get("question")
        choice_a = question_row.get("choice_a")
        choice_b = question_row.get("choice_b")
        choice_c = question_row.get("choice_c")
        user_content = f"{question_text}\nA. {choice_a}\nB. {choice_b}\nC. {choice_c}"
        case_text = question_row.get("case") if exam_type in ("l2", "l3") else None
        if case_text and pd.notna(case_text):
            user_content = f"{case_text}\n\n{user_content}"
        return [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_content}]

    if exam_type in ("gsm", "math", "aime"):
        return [{"role": "user", "content": question_row.get("question") }]

    raise ValueError(f"Unknown exam type: {exam_type}")


def load_generator(model: str = "Qwen/Qwen3-1.7B"):
    """Initializes and returns the generator and PRM score models and tokenizers."""
    accelerator = Accelerator()
    device = accelerator.device
    print(f"Using device: {device}")

    quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.bfloat16
    )

    # --- Generator Model (e.g., a base Llama-3 or any capable LLM) ---
    # Using a smaller, fast model for demonstration. Replace with your preferred generator.
    generator_model_name = model
    if generator_model_name == "Qwen/Qwen3-1.7B":
        generator_model_path = "./model_cache/models--Qwen--Qwen3-1.7B/snapshots/70d244cc86ccca08cf5af4e1e306ecf908b1ad5e"
    elif generator_model_name == "Qwen/Qwen3-4B":
        generator_model_path = "./model_cache/models--Qwen--Qwen3-4B/snapshots/1cfa9a7208912126459214e8b04321603b3df60c"
    elif generator_model_name == "Qwen/Qwen3-8B":
        generator_model_path = "./model_cache/models--Qwen--Qwen3-8B/snapshots/b968826d9c46dd6066d109eabc6255188de91218"
    elif generator_model_name == "llama-1b":
        generator_model_path = "./model_cache/models--meta-llama--Llama-3.2-1B-Instruct/snapshots/9213176726f574b556790deb65791e0c5aa438b6"
    elif generator_model_name == "llama-3b":
        generator_model_path = "./model_cache/models--meta-llama--Llama-3.2-3B-Instruct/snapshots/0cb88a4f764b7a12671c53f0838cd831a0843b95"
    elif generator_model_name == "llama-8b":
        generator_model_path = "./model_cache/models--meta-llama--Llama-3.1-8B-Instruct/snapshots/0e9e39f249a16976918f6564b8830bc894c89659"
    print(f"Loading generator model: {generator_model_path}")
    generator_tokenizer = AutoTokenizer.from_pretrained(generator_model_path, device_map="cuda", local_files_only=True)
    generator_model = AutoModelForCausalLM.from_pretrained(
        generator_model_path, 
        local_files_only=True,
        torch_dtype="auto",
        device_map="cuda",  # Automatically map to available devices
        # quantization_config=quantization_config
    ).eval()
    
    # Many instruction-tuned causal LMs (e.g., Llama) ship without an explicit
    # padding token.  Batch generation utilities in the baselines expect one so
    # we fall back to the EOS token, mirroring Hugging Face's recommended
    # workaround.  Keeping the tokenizer/model config in sync avoids warnings.
    if generator_tokenizer.pad_token is None:
        if generator_tokenizer.eos_token is None:
            generator_tokenizer.add_special_tokens({"pad_token": "<PAD>"})
            added_pad = True
        else:
            generator_tokenizer.pad_token = generator_tokenizer.eos_token
            added_pad = False
    else:
        added_pad = False

    generator_model = AutoModelForCausalLM.from_pretrained(
        generator_model_path, 
        local_files_only=True,
        torch_dtype="auto",
        device_map="cuda",  # Automatically map to available devices
        # quantization_config=quantization_config
    )
    if added_pad:
        generator_model.resize_token_embeddings(len(generator_tokenizer))

    pad_token_id = generator_tokenizer.pad_token_id
    if pad_token_id is not None:
        generator_model.config.pad_token_id = pad_token_id
        if hasattr(generator_model, "generation_config") and generator_model.generation_config is not None:
            generator_model.generation_config.pad_token_id = pad_token_id

    generator_model.eval()
    print(f"Generator model loaded with {generator_model.config.num_hidden_layers} layers and {generator_model.config.hidden_size} hidden size.")

    return (
        generator_model, generator_tokenizer,
        device
    )



def make_baseline(args: argparse.Namespace, model, tokenizer, device: str):
    if args.baseline == "self_consistency":
        config = SelfConsistencyConfig(
            samples=args.sc_samples,
            temperature=args.sc_temperature,
            top_p=args.sc_top_p,
            top_k=args.sc_top_k,
            max_new_tokens=args.max_new_tokens,
            use_answer_extractor=args.sc_use_answer_extractor,
            answer_extractor_max_new_tokens=args.sc_extractor_max_new_tokens,
            answer_extractor_temperature=args.sc_extractor_temperature,
        )
        return SelfConsistencyBaseline(model, tokenizer, config=config, device=device)

    if args.baseline == "segs":
        config = SEGSConfig(
            beam_width=args.segs_beam_width,
            expansions_per_step=args.segs_expansions,
            iterations=args.segs_iterations,
            temperature=args.segs_temperature,
            top_p=args.segs_top_p,
            max_new_tokens=args.max_new_tokens,
        )
        return SelfEvaluationGuidedStochasticBeamSearch(
            model,
            tokenizer,
            config=config,
            device=device,
        )

    if args.baseline == "diverse_beam":
        config = DiverseBeamConfig(
            num_beams=args.dbs_num_beams,
            num_beam_groups=args.dbs_num_groups,
            diversity_penalty=args.dbs_diversity_penalty,
            temperature=args.dbs_temperature,
            top_p=args.dbs_top_p,
            max_new_tokens=args.max_new_tokens,
        )
        return DiverseBeamSearchBaseline(model, tokenizer, config=config, device=device)

    if args.baseline == "conditional_poisson":
        config = ConditionalPoissonConfig(
            beam_width=args.cp_beam_width,
            candidate_multiplier=args.cp_candidate_multiplier,
            temperature=args.cp_temperature,
            top_p=args.cp_top_p,
            max_new_tokens=args.max_new_tokens,
        )
        return ConditionalPoissonBeamSearch(model, tokenizer, config=config, device=device)

    if args.baseline == "nucleus_best_of_n":
        config = NucleusBestOfNConfig(
            samples=args.nucleus_samples,
            top_p=args.nucleus_top_p,
            temperature=args.nucleus_temperature,
            top_k=args.nucleus_top_k,
            max_new_tokens=args.max_new_tokens,
        )
        return NucleusBestOfN(model, tokenizer, config=config, device=device)

    raise ValueError(f"Unknown baseline: {args.baseline}")


def main() -> None:
    args = parse_args()
    rprint(f"[bold]Selected baseline:[/bold] {BASELINE_CHOICES[args.baseline]}")

    df = load_exam_data(args.exam, args.limit, args.start)
    if not args.quiet:
        rprint(f"Loaded {len(df)} questions from {args.exam}")

    model, tokenizer, device = load_generator(args.model)
    baseline = make_baseline(args, model, tokenizer, device)

    if args.out:
        output_dir = args.out
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_safe = args.model.replace("/", "_")
        output_dir = f"results_{args.baseline}_{model_safe}_{args.exam}_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    rprint(f"[bold yellow]Saving results to {output_dir}/[/bold yellow]")

    for idx, row in df.iterrows():
        question_num = args.start + df.index.get_loc(idx)
        messages = format_prompt(args.exam, row)

        if not args.quiet:
            last_message = messages[-1]["content"]
            rprint(f"\n[bold]Question {question_num}[/bold]")
            rprint(f"[cyan]{last_message}[/cyan]")

        try:
            output = baseline.generate(messages)
            response_text = output.get("response", "").strip()
            ground_truth = row.get("answer") if isinstance(row, pd.Series) else None
            if ground_truth is None and isinstance(row, pd.Series):
                ground_truth = row.get("solution")

            result: Dict[str, Any] = {
                "exam": args.exam,
                "question_number": question_num,
                "question": messages[-1]["content"],
                "answer_ground_truth": ground_truth,
                "response_model": response_text,
                "baseline": args.baseline,
                "baseline_output": output,
            }

            if args.exam in ("l1", "l2", "l3"):
                result.update({
                    "question_id": row.get("id") if isinstance(row, pd.Series) else None,
                    "explanation": row.get("explanation") if isinstance(row, pd.Series) else None,
                })
            elif args.exam == "math":
                result.update({
                    "question_id": row.get("unique_id") if isinstance(row, pd.Series) else None,
                    "solution": row.get("solution") if isinstance(row, pd.Series) else None,
                })
            elif args.exam == "aime":
                result.update({
                    "question_id": row.get("id") if isinstance(row, pd.Series) else None,
                    "solution": row.get("solution") if isinstance(row, pd.Series) else None,
                })
            elif args.exam == "gsm":
                result.update({
                    "question_id": idx,
                    "solution": row.get("answer") if isinstance(row, pd.Series) else None,
                })

            question_file = os.path.join(output_dir, f"q{question_num}.json")
            with open(question_file, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

            if not args.quiet:
                truncated_resp = (response_text[:150] + "...") if len(response_text) > 150 else response_text
                rprint(f"[green]Model response:[/green] {truncated_resp}")
                rprint(f"[yellow]Saved to {question_file}[/yellow]")

        except Exception as exc:  # pragma: no cover - runtime safeguard
            rprint(f"[bold red]Error processing question {question_num}: {exc}[/bold red]")
            error_file = os.path.join(output_dir, f"q{question_num}_error.json")
            error_payload = {
                "exam": args.exam,
                "question_number": question_num,
                "question": messages[-1]["content"],
                "error": str(exc),
            }
            with open(error_file, "w", encoding="utf-8") as f:
                json.dump(error_payload, f, indent=2, ensure_ascii=False)

    rprint(f"\n[bold green]Finished processing. Results stored in {output_dir}/[/bold green]")


if __name__ == "__main__":
    main()
