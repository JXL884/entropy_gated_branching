export CUDA_VISIBLE_DEVICES=7

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-1b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 45 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-1b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 45  \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "math" \
#     -o "confidence_beam_search_results/llama-1b/math" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 250 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "math" \
#     -o "confidence_beam_search_results/llama-1b/math" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 250  \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-1b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-1b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 450  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-1b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-1b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 900  \
#     --llama \

###############################################


# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-3b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 45 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-3b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 45  \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "math" \
#     -o "confidence_beam_search_results/llama-3b/math" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 250 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "math" \
#     -o "confidence_beam_search_results/llama-3b/math" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 250  \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 450  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 900  \
#     --llama \



###############################################


# python3 run_beam_search.py \
#     --model "llama-8b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-8b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 45 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-8b" \
#     --exam "aime" \
#     -o "confidence_beam_search_results/llama-8b/aime" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 45  \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-8b" \
#     --exam "math" \
#     -o "confidence_beam_search_results/llama-8b/math" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 250 \
#     --llama \

python3 run_beam_search.py \
    --model "llama-8b" \
    --exam "math" \
    -o "confidence_beam_search_results/llama-8b/math" \
    --quiet \
    --entropy-threshold 2 \
    --confidence-beam-search \
    --start 250  \
    --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 1  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 450  \
#     --limit 450 \
#     --llama \

# python3 run_beam_search.py \
#     --model "llama-3b" \
#     --exam "gsm" \
#     -o "confidence_beam_search_results/llama-3b/gsm" \
#     --quiet \
#     --entropy-threshold 2 \
#     --confidence-beam-search \
#     --start 900  \
#     --llama \