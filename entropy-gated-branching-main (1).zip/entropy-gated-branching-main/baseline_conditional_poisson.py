"""Conditional-Poisson stochastic beam search baseline."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import torch
from transformers import PreTrainedModel, PreTrainedTokenizerBase
from baseline_utils import generate_samples, generation_timer



@dataclass
class ConditionalPoissonConfig:
    beam_width: int = 4
    candidate_multiplier: int = 4
    temperature: float = 0.7
    top_p: float = 0.95
    max_new_tokens: int = 512


def _solve_lambda(weights: torch.Tensor, target: int) -> torch.Tensor:
    if target <= 0:
        return torch.tensor(0.0, device=weights.device)

    low = torch.tensor(0.0, device=weights.device)
    high = torch.tensor(1.0, device=weights.device)

    def inclusion_prob(lmbd: torch.Tensor) -> torch.Tensor:
        return torch.clamp(lmbd * weights, max=1.0)

    while inclusion_prob(high).sum() < target:
        high *= 2

    for _ in range(32):
        mid = (low + high) / 2
        prob_sum = inclusion_prob(mid).sum()
        if prob_sum > target:
            high = mid
        else:
            low = mid

    return high


def conditional_poisson_sample(weights: torch.Tensor, k: int) -> List[int]:
    if weights.numel() == 0:
        return []

    if weights.sum() <= 0:
        weights = torch.ones_like(weights)

    lmbd = _solve_lambda(weights, k)
    probs = torch.clamp(lmbd * weights, max=1.0)
    mask = torch.rand_like(probs) < probs
    chosen = torch.nonzero(mask, as_tuple=False).flatten().tolist()

    if len(chosen) < k:
        remaining = sorted(
            [(idx, weight.item()) for idx, weight in enumerate(weights) if idx not in chosen],
            key=lambda item: item[1],
            reverse=True,
        )
        chosen.extend(idx for idx, _ in remaining[: k - len(chosen)])
    elif len(chosen) > k:
        chosen = sorted(chosen, key=lambda idx: weights[idx].item(), reverse=True)[:k]

    return chosen


class ConditionalPoissonBeamSearch:
    """Samples candidate continuations without replacement using CP design."""

    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizerBase,
        config: Optional[ConditionalPoissonConfig] = None,
        *,
        device: Optional[str] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or ConditionalPoissonConfig()
        self.device = device or str(model.device)

    def _generation_kwargs(self) -> Dict[str, object]:
        cfg = self.config
        return {
            "do_sample": True,
            "temperature": cfg.temperature,
            "top_p": cfg.top_p,
        }

    def generate(self, prompt) -> Dict[str, object]:
        cfg = self.config
        num_candidates = max(cfg.candidate_multiplier * cfg.beam_width, cfg.beam_width)

        with generation_timer() as timing:
            candidates = generate_samples(
                self.model,
                self.tokenizer,
                prompt,
                num_samples=num_candidates,
                max_new_tokens=cfg.max_new_tokens,
                generation_kwargs=self._generation_kwargs(),
                device=self.device,
            )

            weights = torch.tensor([candidate.logprob for candidate in candidates], device=self.model.device)
            weights = torch.nn.functional.softmax(weights, dim=0)
            selected_indices = conditional_poisson_sample(weights, cfg.beam_width)

            selected = [candidates[idx] for idx in selected_indices]
            best = max(selected, key=lambda sample: sample.logprob)



        return {
            "response": best.text,
            "logprob": best.logprob,
            "token_count": best.token_count,
            "selected_indices": selected_indices,
            "candidates": [
                {
                    "text": candidate.text,
                    "logprob": candidate.logprob,
                    "token_count": candidate.token_count,
                }
                for candidate in candidates
            ],
            "timing": timing,

        }

